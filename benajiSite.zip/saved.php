<?php include './master.php' ?>
<?php nav();?>

  <!-- ======= Get Started Section ======= -->
  <section id="get-started" class="padd-section text-center">

<div class="container" data-aos="fade-up" style="margin-top:80px;">
  <div class="section-title text-center">

    <h2>Bookmarked Designs </h2>
    <p class="separator">All your Saved Designs Here .</p>

  </div>
</div>

<div class="container">
  <div class="row designsSavedCards">
    
  </div>
</div>

</section><!-- End Get Started Section -->

 <?php footer();?>
<script src="javascriptFiles/saved.js"></script>
