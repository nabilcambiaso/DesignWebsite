<?php include './master.php' ?>
<?php nav();?>

 
<div class="container-fluid" style="margin-top: 80px; ">
<br>
<div class="container">
<div class="row"  style="background:#F2FAF1; border-radius:15px; padding: 10px 0;">

<div class="col-xs-6 col-md-4 col-sm-6" >
    <input type="search" name="searchDesign" id="SearchDesignInput" placeholder="  Search" style="width:100%; padding-left:10px; border-radius:15px; border:solid #EDF8EB;">
</div>
<div class="col-xs-6 col-md-4 col-sm-6">
<select  name="selectDesign" id="selectCategoryDesign"  style="width:100%; padding:1px 10px; border-radius:15px; border:solid #EDF8EB;">
<option style="color:#71C55D;" value="">...Categories&nbsp;&nbsp;<span>&nbsp;&nbsp;&nbsp;(All)</span></option>
</select>
</div>
<div class="col-xs-0 col-md-3 col-sm-0"></div>
</div>
</div>
<div class="container_fluid" style="min-height:60vh;">
 <!-- ======= Team Section ======= -->
 <section id="team" class="padd-section text-center">

<div class="container" data-aos="fade-up">
  <div class="section-title text-center">

    <h2>Majda Design</h2>
    <p class="separator">You Can Message Us About The Design You Like Just Click On It  </p>
  </div>

  <div class="row designsPic" >

    
  </div>
</div>
</section><!-- End Team Section -->


</div>



<div class="container">
<nav aria-label="Page navigation example" style="margin:40px 0;">
  <ul class="pagination justify-content-center">
    <li class="page-item disabled">
      <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
    </li>
    <li class="page-item"><a class="page-link" href="#">1</a></li>
    <li class="page-item"><a class="page-link" href="#">2</a></li>
    <li class="page-item"><a class="page-link" href="#">3</a></li>
    <li class="page-item">
      <a class="page-link" href="#">Next</a>
    </li>
  </ul>
</nav>
</div>

</div>

<?php footer();?>
<script src="javascriptFiles/design.js"></script>
