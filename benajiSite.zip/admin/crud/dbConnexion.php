<?php
$mysqli = new mysqli('localhost','root','','majdaDb') or die(mysqli_error($mysqli));
?>