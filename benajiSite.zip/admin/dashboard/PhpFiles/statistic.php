<?php
include "../../crud/dbConnexion.php";
//all designs
if(isset($_POST['totalDesigns'])){
  $num=[];
    $sql = "select count(*) as nbr from design ";
    $req=$mysqli->query($sql) or die(mysqli_error());
    while($ligne=mysqli_fetch_assoc($req)) {
         $num[]=$ligne;
    }    
    echo json_encode($num);
}

//all designs
if(isset($_POST['totalProducts'])){
  $num=[];
    $sql = "select count(*) as nbr from products ";
    $req=$mysqli->query($sql) or die(mysqli_error());
    while($ligne=mysqli_fetch_assoc($req)) {
         $num[]=$ligne;
    }    
    echo json_encode($num);
}




?>